Rails.application.routes.draw do
  get 'pages/lesgossips'

  get 'pages/newaccount'

  get 'pages/home'

  get 'pages/login'

  get 'login' => 'pages#login'
  get 'gossips' => 'pages#login'
  get 'newaccount' => 'pages#newaccount'

  root 'pages#lesgossips'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
