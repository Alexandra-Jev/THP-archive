class PagesController < ApplicationController
  def lesgossips
  end
end
